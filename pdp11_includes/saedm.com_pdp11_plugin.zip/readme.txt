1 - make sure that the simulator files are all in c:\pdp11\ directory
2 - put the .bat files into this directory
3- put the dll file into c:\program files\notepad++\plugins\ (or wherever you installed it\plugins)


Author: Saed Mansour
For feedback: saed.mn@gmail.com